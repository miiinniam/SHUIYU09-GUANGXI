# 水鱼发牌神器

广西水鱼酒桌专用发牌助手。当前版本是静态 H5 应用，使用 Firebase Realtime Database 同步房间、共享牌堆、玩家手牌和记酒器。

## 免费开发方案

- 页面托管：Vercel Hobby 免费额度。
- 实时数据库：Firebase Spark 免费方案的 Realtime Database。
- 本地构建：Node.js 自带脚本，无需付费后端。

Firebase 浏览器配置本身不是密钥，前端可见是正常的；安全边界主要依赖 Realtime Database Rules。

## 本地准备

1. 复制环境变量示例：

```bash
cp .env.example .env.local
```

2. 在 `.env.local` 填入 Firebase Web App 配置：

```bash
FIREBASE_API_KEY=
FIREBASE_AUTH_DOMAIN=
FIREBASE_DATABASE_URL=
FIREBASE_PROJECT_ID=
FIREBASE_STORAGE_BUCKET=
FIREBASE_MESSAGING_SENDER_ID=
FIREBASE_APP_ID=
```

## 本地虚拟运行

如果只是想先在本机试用，不需要创建 Firebase 项目。使用示例配置构建后，在 localhost 打开时会自动进入本地模拟数据库模式：

```bash
FIREBASE_API_KEY=example FIREBASE_AUTH_DOMAIN=example.firebaseapp.com FIREBASE_DATABASE_URL=https://example-default-rtdb.firebaseio.com FIREBASE_PROJECT_ID=example FIREBASE_STORAGE_BUCKET=example.appspot.com FIREBASE_MESSAGING_SENDER_ID=123 FIREBASE_APP_ID=app npm run build
npm run preview
```

然后打开：

```text
http://localhost:4173/index.html
```

本地模拟模式说明：

- 房间、玩家、手牌、记酒器会写入浏览器 `localStorage`。
- 同一个浏览器开两个标签页，可以模拟两台手机加入同一个房间。
- 这只适合本地体验，不适合发给别人在线使用。
- 要清空虚拟房间，打开浏览器控制台执行：

```js
localStorage.removeItem('shuiyu_mock_db')
```

## Firebase Setup

1. 创建 Firebase 项目，选择 Spark 免费方案。
2. 创建 Web App，复制 Firebase config。
3. 启用 Realtime Database。
4. 在 Realtime Database 的 Rules 页面粘贴 `firebase.rules.json` 中的规则。
5. 把 Firebase config 的 7 个字段填入 `.env.local` 和 Vercel 环境变量。

## 本地构建

当前构建脚本会从环境变量读取 Firebase 配置，并生成 `dist/firebase-config.js`。

```bash
npm run build
```

如果没有设置 Firebase 环境变量，构建会明确失败并提示缺少哪些变量。

## 本地预览

```bash
npm run build
npm run preview
```

打开终端输出的本地地址即可预览。

## 部署到 Vercel

1. 安装并登录 Vercel CLI。

```bash
npm install -g vercel
vercel login
```

2. 在项目根目录链接 Vercel 项目：

```bash
vercel link
```

3. 在 Vercel Dashboard 的 Project Settings -> Environment Variables 添加：

```bash
FIREBASE_API_KEY
FIREBASE_AUTH_DOMAIN
FIREBASE_DATABASE_URL
FIREBASE_PROJECT_ID
FIREBASE_STORAGE_BUCKET
FIREBASE_MESSAGING_SENDER_ID
FIREBASE_APP_ID
```

4. 部署预览链接：

```bash
vercel
```

5. 部署正式链接：

```bash
vercel --prod
```

部署成功后，Vercel 会返回一个 `https://*.vercel.app` 链接，玩家手机打开这个链接即可创建或加入房间。

## 上线后验收

1. 手机 A 打开正式链接并创建房间。
2. 手机 B 打开同一链接并输入房间号加入。
3. 庄家点击发牌。
4. 两台手机收到不同的 4 张牌。
5. 拖牌到头牌区和尾牌区后，底部结果实时更新。
6. 对子只显示“保”，双保显示“水鱼！”。
7. 一台手机调整记酒器，另一台手机同步更新。
8. 刷新页面后房间状态仍能恢复。

## Current Limitations

- 房间使用 4 位数字码，知道房间号的人都可以加入。
- 当前没有登录系统。
- 旧房间还不会自动清理。
- 免费额度适合小范围酒桌使用，公开大范围传播前需要监控 Firebase 用量。
