/**
 * 水鱼发牌神器 - 游戏核心逻辑
 */

const G = {
  roomId: null,
  playerId: null,
  room: null,
  myData: null,
  isVariant: false,
  cards: [],
  head: [],
  tail: [],
  isCovered: true,
  revealedCardIds: new Set(),
  justRevealedCardId: null,
  result: null,
  unwatchRoom: null,
  unwatchMe: null,
  shuiyuShown: false,
  lastRenderSignature: '',
  lastHandSignature: '',
  syncTimer: null
};

function show(id) { document.getElementById(id)?.classList.remove('hidden'); }
function hide(id) { document.getElementById(id)?.classList.add('hidden'); }
function loading(show_) { show_ ? show('loading') : hide('loading'); }

function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  el.classList.add('toast-anim');
  setTimeout(() => { el.classList.add('hidden'); el.classList.remove('toast-anim'); }, 2200);
}

function cardPoint(card) {
  return card?.point ?? 0;
}

function isWildCard(card) {
  return Boolean(card?.isJoker || card?.isFlower);
}

function sameRankCards(c1, c2) {
  return !isWildCard(c1) && !isWildCard(c2) && c1?.rank === c2?.rank;
}

function cardRankLabel(card) {
  if (card?.isJoker) return card.rank === '大王' ? '大' : '小';
  if (card?.isFlower) return '花';
  return card?.rank || '';
}

function scoreGroup(cards) {
  if (!cards || cards.length !== 2) return -1;
  const p1 = cardPoint(cards[0]);
  const p2 = cardPoint(cards[1]);
  if (sameRankCards(cards[0], cards[1]) || isWildCard(cards[0]) || isWildCard(cards[1])) return 100 + Math.max(p1, p2);
  return (p1 + p2) % 10;
}

function isBaoGroup(cards) {
  return cards?.length === 2 && (sameRankCards(cards[0], cards[1]) || isWildCard(cards[0]) || isWildCard(cards[1]));
}

function findShuiyuArrangement(cards) {
  if (!cards || cards.length !== 4) return null;
  const splits = [
    [[cards[0], cards[1]], [cards[2], cards[3]]],
    [[cards[0], cards[2]], [cards[1], cards[3]]],
    [[cards[0], cards[3]], [cards[1], cards[2]]]
  ];

  for (const [a, b] of splits) {
    if (isBaoGroup(a) && isBaoGroup(b)) {
      return scoreGroup(a) >= scoreGroup(b)
        ? { head: a, tail: b }
        : { head: b, tail: a };
    }
  }
  return null;
}

function autoArrangeHand(cards) {
  if (!cards || cards.length !== 4) return { head: [], tail: [] };
  const shuiyu = findShuiyuArrangement(cards);
  if (shuiyu) return shuiyu;

  const splits = [
    [[cards[0], cards[1]], [cards[2], cards[3]]],
    [[cards[0], cards[2]], [cards[1], cards[3]]],
    [[cards[0], cards[3]], [cards[1], cards[2]]]
  ];

  let best = splits[0];
  let bestDelta = -Infinity;
  for (const [a, b] of splits) {
    const high = scoreGroup(a) >= scoreGroup(b) ? a : b;
    const low = high === a ? b : a;
    const delta = scoreGroup(high) - scoreGroup(low);
    if (delta > bestDelta) {
      bestDelta = delta;
      best = [high, low];
    }
  }

  return { head: best[0], tail: best[1] };
}

function handSignature(cards = [], head = [], tail = []) {
  const ids = (list) => list.map(c => `${c.id}:${cardPoint(c)}`).join(',');
  return `${ids(cards)}|${ids(head)}|${ids(tail)}|${G.isCovered}|${[...G.revealedCardIds].sort().join(',')}`;
}

function dealSignature(cards = []) {
  return cards.map(c => `${c.id}:${cardPoint(c)}`).sort().join(',');
}

function ensureAutoArrangement(me) {
  if (!me?.hand || me.hand.length !== 4) return false;
  const hasServerLayout = (me.head?.length || 0) + (me.tail?.length || 0) > 0;
  if (hasServerLayout) return false;
  const arranged = autoArrangeHand(me.hand);
  G.head = arranged.head;
  G.tail = arranged.tail;
  syncHandDebounced(10);
  return true;
}

function resetRevealState(isCovered = true) {
  G.isCovered = isCovered;
  G.revealedCardIds = new Set();
  G.justRevealedCardId = null;
  const cover = document.getElementById('in-cover');
  if (cover) cover.checked = isCovered;
}

function resetLocalTable() {
  G.cards = [];
  G.head = [];
  G.tail = [];
  resetRevealState(true);
  G.shuiyuShown = false;
  G.lastHandSignature = '';
  G.lastRenderSignature = '';
}

function setNewHand(cards, head, tail) {
  const nextDealSignature = dealSignature(cards);
  const isNewHand = nextDealSignature !== G.lastHandSignature;
  G.cards = cards || [];
  G.head = head || [];
  G.tail = tail || [];

  if (isNewHand) {
    G.lastHandSignature = nextDealSignature;
    resetRevealState(true);
    G.lastRenderSignature = '';
  }
}

function cardHTML(card, zone, index = 0) {
  if (!card) return '';
  const covered = G.isCovered && !G.revealedCardIds.has(card.id);
  const justRevealed = !covered && G.justRevealedCardId === card.id;
  const sizeClass = zone === 'temp'
    ? 'card-temp'
    : 'card-large';
  const revealClass = justRevealed ? `card-flip-reveal ${isWildCard(card) ? 'card-wild-reveal' : ''}` : '';
  const visualClass = covered
    ? 'bg-[#18231f] border border-[#c7a15a]/35'
    : isWildCard(card)
      ? 'bg-[#f4ead6] border border-[#c7a15a]'
      : 'bg-[#f7f2e8] border border-black/10';
  const red = card.suit === '♥' || card.suit === '♦';
  const colorClass = red ? 'text-[#a33b38]' : 'text-[#171a18]';
  const suit = card.isJoker ? '王' : card.isFlower ? '花' : card.suit;
  const rank = cardRankLabel(card);
  const wildBadge = isWildCard(card) ? '<div class="absolute top-1 right-1 text-[10px] bg-[#c7a15a] text-[#17120a] px-1 rounded-md font-black">配</div>' : '';
  const coverHTML = `
    <div class="absolute inset-0 rounded-[10px] bg-[#18231f] border border-[#c7a15a]/40 flex items-center justify-center">
      <div class="w-10 h-10 rounded-full border border-[#c7a15a]/55 flex items-center justify-center text-[#c7a15a] text-2xl font-black">水</div>
    </div>`;
  const faceHTML = `
    <div class="absolute top-1 left-2 text-[clamp(11px,3vw,18px)] ${colorClass} font-bold flex flex-col items-center leading-none">
      <span>${rank}</span>
      <span class="text-[0.65em]">${suit}</span>
    </div>
    ${wildBadge}
    <div class="text-[clamp(28px,10vw,58px)] ${colorClass} font-serif font-bold">${suit}</div>
    <div class="absolute bottom-1 right-2 text-[clamp(11px,3vw,18px)] ${colorClass} font-bold flex flex-col items-center leading-none rotate-180">
      <span>${rank}</span>
      <span class="text-[0.65em]">${suit}</span>
    </div>`;

  return `
    <div class="poker-card ${sizeClass} ${visualClass} ${revealClass} rounded-[10px] relative flex flex-col items-center justify-center cursor-grab select-none shadow-lg shadow-black/25"
         data-card-index="${index}" data-card-id="${card.id}" data-zone="${zone}">
      ${covered ? coverHTML : faceHTML}
    </div>
  `;
}

function playShuiyuEffect() {
  const effect = document.getElementById('shuiyu-effect');
  if (!effect) return;
  effect.classList.remove('hidden', 'shuiyu-effect-run');
  void effect.offsetWidth;
  effect.classList.add('shuiyu-effect-run');
  setTimeout(() => effect.classList.add('hidden'), 1800);
}

function renderCards(force = false) {
  const rowTemp = document.getElementById('row-temp');
  const rowHead = document.getElementById('row-head');
  const rowTail = document.getElementById('row-tail');
  if (!rowTemp || !rowHead || !rowTail) return;

  const signature = handSignature(G.cards, G.head, G.tail);
  if (!force && signature === G.lastRenderSignature) return;
  G.lastRenderSignature = signature;

  const inHead = new Set(G.head.map(c => c.id));
  const inTail = new Set(G.tail.map(c => c.id));
  const unassigned = G.cards.filter(c => !inHead.has(c.id) && !inTail.has(c.id));

  rowTemp.innerHTML = unassigned.map(card => cardHTML(card, 'temp', G.cards.findIndex(c => c.id === card.id))).join('');
  rowHead.innerHTML = G.head.map(card => cardHTML(card, 'head', G.cards.findIndex(c => c.id === card.id))).join('');
  rowTail.innerHTML = G.tail.map(card => cardHTML(card, 'tail', G.cards.findIndex(c => c.id === card.id))).join('');

  bindDrag();
}

function refreshResult() {
  const elH = document.getElementById('res-head');
  const elT = document.getElementById('res-tail');
  const elS = document.getElementById('res-shuiyu');
  const elSummary = document.getElementById('res-summary');
  const elC = document.getElementById('msg-covered');
  if (!elH || !elT || !elS || !elSummary || !elC) return;

  const showSummaryOnly = (text) => {
    elH.textContent = '';
    elT.textContent = '';
    elH.classList.add('hidden');
    elT.classList.add('hidden');
    elSummary.textContent = text;
    elSummary.classList.remove('hidden');
  };

  const showSideResults = () => {
    elH.classList.remove('hidden');
    elT.classList.remove('hidden');
    elSummary.classList.add('hidden');
  };

  if (G.isCovered) {
    showSideResults();
    elH.textContent = '?';
    elT.textContent = '?';
    elH.className = 'result-value text-paper/60';
    elT.className = 'result-value text-paper/60';
    elS.classList.add('hidden');
    elSummary.classList.add('hidden');
    elC.classList.remove('hidden');
    return;
  }

  elC.classList.add('hidden');
  if (G.head.length === 2 && G.tail.length === 2) {
    const res = Calculator.shuiyu(G.head, G.tail);
    G.result = res;
    if (res.isShuiyu) {
      elH.textContent = '';
      elT.textContent = '';
      elH.classList.add('hidden');
      elT.classList.add('hidden');
      elSummary.classList.add('hidden');
      elS.classList.remove('hidden');
      elS.classList.add('shuiyu-glow', 'shuiyu-flash');
      setTimeout(() => elS.classList.remove('shuiyu-flash'), 1600);
      if (G.isVariant && !G.shuiyuShown) {
        G.shuiyuShown = true;
        playShuiyuEffect();
        setTimeout(() => {
          shuiyuReset(G.roomId, G.playerId);
          toast('水鱼！该玩家坐庄，等待发牌');
        }, 1600);
      }
    } else {
      elS.classList.add('hidden');
      if (res.summary) {
        showSummaryOnly(res.summary);
      } else {
        showSideResults();
        elH.textContent = res.left;
        elT.textContent = res.right;
        elH.className = 'result-value ' + (res.head.isBao ? 'text-danger' : 'text-paper');
        elT.className = 'result-value ' + (res.tail.isBao ? 'text-danger' : 'text-paper');
        elSummary.classList.add('hidden');
      }
      G.shuiyuShown = false;
    }
  } else {
    showSideResults();
    elH.textContent = '-';
    elT.textContent = '-';
    elH.className = 'result-value text-paper/30';
    elT.className = 'result-value text-paper/30';
    elS.classList.add('hidden');
    elSummary.classList.add('hidden');
  }
}

function refreshUI() {
  if (!G.room) return;
  const isDealer = G.room.dealer === G.playerId;
  document.getElementById('disp-game-room').textContent = '房间 ' + G.room.roomId;
  document.getElementById('disp-my-name').textContent = G.myData?.name || '我';
  const roleEl = document.getElementById('disp-my-role');
  roleEl.textContent = isDealer ? '庄家' : '闲家';
  roleEl.className = 'text-[11px] font-semibold px-2 py-0.5 rounded-md ' + (isDealer ? 'bg-brass text-black' : 'bg-white/10 text-paper/65');
  document.getElementById('disp-drink').textContent = G.room.drinkCount || 0;
  document.getElementById('disp-remaining').textContent = G.room.deck?.cards?.length || 0;
  document.getElementById('btn-switch-dealer').style.display = isDealer ? 'inline-flex' : 'none';
  document.getElementById('btn-deal').disabled = !isDealer;
  document.getElementById('btn-shuffle').disabled = !isDealer;
  const variantToggle = document.getElementById('in-variant-game');
  if (variantToggle) {
    variantToggle.checked = Boolean(G.room.isVariant);
    variantToggle.disabled = !isDealer;
    variantToggle.parentElement?.classList.toggle('opacity-50', !isDealer);
  }
  document.getElementById('deal-label').textContent = isDealer ? '发牌' : '等待庄家';
  document.getElementById('btn-deal').classList.toggle('opacity-50', !isDealer);
  document.getElementById('btn-shuffle').classList.toggle('opacity-50', !isDealer);
}

let draggedEl = null;
let draggedIdx = -1;
let dragStartX = 0;
let dragStartY = 0;
let dragged = false;

function bindDrag() {
  document.querySelectorAll('.poker-card').forEach(el => {
    el.addEventListener('touchstart', handleTouchStart, { passive: false });
    el.addEventListener('mousedown', handleMouseDown);
  });
}

function handleMouseDown(e) {
  const card = e.target.closest('.poker-card');
  if (!card) return;
  e.preventDefault();
  startDrag(card, e.clientX, e.clientY);
  document.addEventListener('mousemove', handleMouseMove);
  document.addEventListener('mouseup', handleMouseUp);
}
function handleMouseMove(e) { moveDrag(e.clientX, e.clientY); }
function handleMouseUp(e) {
  endDrag(e.clientX, e.clientY);
  document.removeEventListener('mousemove', handleMouseMove);
  document.removeEventListener('mouseup', handleMouseUp);
}
function handleTouchStart(e) {
  const card = e.target.closest('.poker-card');
  if (!card) return;
  e.preventDefault();
  const t = e.touches[0];
  startDrag(card, t.clientX, t.clientY);
  document.addEventListener('touchmove', handleTouchMove, { passive: false });
  document.addEventListener('touchend', handleTouchEnd);
}
function handleTouchMove(e) {
  e.preventDefault();
  const t = e.touches[0];
  moveDrag(t.clientX, t.clientY);
}
function handleTouchEnd(e) {
  const t = e.changedTouches[0];
  endDrag(t.clientX, t.clientY);
  document.removeEventListener('touchmove', handleTouchMove);
  document.removeEventListener('touchend', handleTouchEnd);
}

function startDrag(el, x, y) {
  draggedEl = el;
  draggedIdx = parseInt(el.dataset.cardIndex, 10);
  dragStartX = x;
  dragStartY = y;
  dragged = false;
  const ghost = el.cloneNode(true);
  ghost.id = 'drag-ghost';
  ghost.style.cssText = `position:fixed;left:${x - 45}px;top:${y - 60}px;z-index:9999;pointer-events:none;opacity:0.92;transform:scale(1.05);`;
  document.body.appendChild(ghost);
  el.style.opacity = '0.35';
  ['zone-head', 'zone-tail', 'zone-temp'].forEach(id => document.getElementById(id)?.classList.add('drop-active'));
}

function moveDrag(x, y) {
  if (Math.abs(x - dragStartX) + Math.abs(y - dragStartY) > 10) dragged = true;
  const ghost = document.getElementById('drag-ghost');
  if (ghost) {
    ghost.style.left = (x - 45) + 'px';
    ghost.style.top = (y - 60) + 'px';
  }
  ['zone-head', 'zone-tail', 'zone-temp'].forEach(id => {
    const zone = document.getElementById(id);
    if (!zone) return;
    const r = zone.getBoundingClientRect();
    zone.classList.toggle('drop-highlight', x >= r.left && x <= r.right && y >= r.top && y <= r.bottom);
  });
}

function endDrag(x, y) {
  document.getElementById('drag-ghost')?.remove();
  if (draggedEl) draggedEl.style.opacity = '1';
  const targetDrop = findDropIntent(x, y);
  if (!dragged && draggedEl) {
    const card = G.cards[draggedIdx];
    if (card) handleCardTap(card);
  } else if (targetDrop && draggedIdx >= 0) {
    handleDrop(targetDrop.zoneId, draggedIdx, targetDrop.insertIndex);
  }
  ['zone-head', 'zone-tail', 'zone-temp'].forEach(id => document.getElementById(id)?.classList.remove('drop-active', 'drop-highlight'));
  draggedEl = null;
  draggedIdx = -1;
}

function findDropIntent(x, y) {
  for (const id of ['zone-head', 'zone-tail', 'zone-temp']) {
    const zone = document.getElementById(id);
    if (!zone) continue;
    const r = zone.getBoundingClientRect();
    if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) {
      return { zoneId: id, insertIndex: getCardDropIndex(zone, x) };
    }
  }
  return null;
}

function getCardDropIndex(zone, x) {
  const cards = [...zone.querySelectorAll('.poker-card')].filter(card => card !== draggedEl);
  for (let i = 0; i < cards.length; i++) {
    const r = cards[i].getBoundingClientRect();
    if (x < r.left + r.width / 2) return i;
  }
  return cards.length;
}

function handleCardTap(card) {
  toggleCardReveal(card.id);
}

function syncCoverStateFromRevealedCards() {
  const allRevealed = G.cards.length > 0 && G.cards.every(card => G.revealedCardIds.has(card.id));
  G.isCovered = !allRevealed;
  const cover = document.getElementById('in-cover');
  if (cover) cover.checked = G.isCovered;
}

function toggleCardReveal(cardId) {
  if (G.revealedCardIds.has(cardId)) {
    G.revealedCardIds.delete(cardId);
    G.justRevealedCardId = null;
  } else {
    G.revealedCardIds.add(cardId);
    G.justRevealedCardId = cardId;
  }
  syncCoverStateFromRevealedCards();
  renderCards(true);
  refreshResult();
  setTimeout(() => {
    if (G.justRevealedCardId === cardId) G.justRevealedCardId = null;
  }, 900);
}

function removeFromZones(cardId) {
  const fromHead = G.head.find(c => c.id === cardId);
  const fromTail = G.tail.find(c => c.id === cardId);
  G.head = G.head.filter(c => c.id !== cardId);
  G.tail = G.tail.filter(c => c.id !== cardId);
  return fromHead ? 'head' : fromTail ? 'tail' : 'temp';
}

function handleDrop(zoneId, cardIndex, insertIndex = 2) {
  const card = G.cards[cardIndex];
  if (!card) return;
  const from = removeFromZones(card.id);
  const target = zoneId === 'zone-head' ? G.head : zoneId === 'zone-tail' ? G.tail : null;
  if (target) {
    if (target.length >= 2) {
      const replaceIndex = Math.min(Math.max(insertIndex, 0), target.length - 1);
      const displaced = target.splice(replaceIndex, 1, card)[0];
      if (from === 'head') G.head.push(displaced);
      if (from === 'tail') G.tail.push(displaced);
    } else {
      const targetIndex = Math.min(Math.max(insertIndex, 0), target.length);
      target.splice(targetIndex, 0, card);
    }
  }
  renderCards(true);
  refreshResult();
  syncHandDebounced();
}

async function syncHand() {
  if (!G.roomId || !G.playerId) return;
  await updatePlayerHand(G.roomId, G.playerId, G.head, G.tail);
}

function syncHandDebounced(delay = 180) {
  clearTimeout(G.syncTimer);
  G.syncTimer = setTimeout(syncHand, delay);
}

async function doDeal() {
  if (G.room?.dealer !== G.playerId) return toast('等待庄家发牌');
  loading(true);
  try {
    const res = await dealFromSharedDeck(G.roomId);
    if (res.success) {
      G.shuiyuShown = false;
      resetRevealState(true);
      if (res.remaining < 8) toast('本副牌即将结束，可洗牌');
    } else {
      toast(res.reason === '牌已用尽' ? '牌已用尽，请洗牌' : '发牌失败');
    }
  } catch (e) {
    toast('发牌失败: ' + e.message);
  } finally {
    loading(false);
  }
}

async function doShuffle() {
  if (G.room?.dealer !== G.playerId) return toast('只有庄家可以洗牌');
  if (!confirm('确定重新洗牌？当前手牌会清空。')) return;
  loading(true);
  try {
    await window.ShuiyuFirebase.resetSharedDeck(G.roomId);
    resetLocalTable();
    renderCards(true);
    refreshResult();
    toast('已重新洗牌');
  } catch (e) {
    toast('洗牌失败');
  } finally {
    loading(false);
  }
}

async function handleGameVariantChange() {
  const toggle = document.getElementById('in-variant-game');
  const nextVariant = Boolean(toggle?.checked);
  if (G.room?.dealer !== G.playerId) {
    if (toggle) toggle.checked = Boolean(G.room?.isVariant);
    return toast('只有庄家可以切换变牌');
  }

  loading(true);
  try {
    const res = await window.ShuiyuFirebase.updateRoomVariant(G.roomId, nextVariant);
    if (!res.success) {
      if (toggle) toggle.checked = Boolean(G.room?.isVariant);
      return toast(res.reason || '切换失败');
    }
    resetLocalTable();
    renderCards(true);
    refreshResult();
    toast(nextVariant ? '已开启变牌，重新洗牌' : '已关闭变牌，重新洗牌');
  } catch {
    if (toggle) toggle.checked = Boolean(G.room?.isVariant);
    toast('切换失败');
  } finally {
    loading(false);
  }
}

function showSwitchModal() {
  const players = G.room?.players || {};
  const current = G.room?.dealer;
  const list = document.getElementById('list-players');
  const modal = document.getElementById('modal-switch');
  let selected = null;
  list.innerHTML = Object.entries(players).map(([pid, p]) => `
    <div class="player-item flex items-center gap-3 p-3 bg-white/5 rounded-lg cursor-pointer hover:bg-white/10 transition ${pid === current ? 'opacity-50 cursor-not-allowed' : ''}" data-id="${pid}">
      <div class="w-10 h-10 rounded-lg bg-brass text-black flex items-center justify-center text-lg font-bold">${p.name?.[0] || '?'}</div>
      <div><div class="font-semibold">${p.name || '玩家'}</div>${pid === current ? '<div class="text-xs text-brass">当前庄家</div>' : ''}</div>
    </div>`).join('');
  list.querySelectorAll('.player-item').forEach(item => {
    item.addEventListener('click', () => {
      if (item.dataset.id === current) return;
      selected = item.dataset.id;
      list.querySelectorAll('.player-item').forEach(i => i.classList.remove('ring-2', 'ring-brass', 'bg-white/15'));
      item.classList.add('ring-2', 'ring-brass', 'bg-white/15');
    });
  });
  document.getElementById('btn-confirm-switch').onclick = async () => {
    if (!selected) return toast('请选择一位玩家');
    loading(true);
    modal.classList.add('hidden');
    try {
      await switchDealer(G.roomId, selected);
      toast('换庄成功，已重新洗牌');
    } catch {
      toast('换庄失败');
    } finally {
      loading(false);
    }
  };
  modal.classList.remove('hidden');
}

async function updateDrinkCount(delta) {
  if (!G.roomId) return;
  await window.ShuiyuFirebase.updateDrink(G.roomId, delta);
}

async function exitRoom() {
  if (!confirm('确定退出房间？')) return;
  if (G.roomId && G.playerId) await leaveRoom(G.roomId, G.playerId);
  window.location.href = 'index.html';
}

function applyPlayerData(me) {
  if (!me) return;
  G.myData = me;
  if (!me.hand) {
    setNewHand([], [], []);
    renderCards();
    return;
  }
  setNewHand(me.hand, me.head || [], me.tail || []);
  const arranged = ensureAutoArrangement(me);
  renderCards(arranged);
  refreshResult();
}

async function initGame(roomId, playerId) {
  G.roomId = roomId;
  G.playerId = playerId;
  show('page-game');
  hide('page-home');
  hide('page-setting');

  document.getElementById('in-cover').addEventListener('change', e => {
    G.isCovered = e.target.checked;
    if (G.isCovered) {
      resetRevealState(true);
    } else {
      G.cards.forEach(card => G.revealedCardIds.add(card.id));
      G.justRevealedCardId = null;
    }
    renderCards(true);
    refreshResult();
  });

  G.unwatchRoom = watchRoom(roomId, (room) => {
    G.room = room;
    G.isVariant = room.isVariant;
    applyPlayerData(room.players?.[playerId]);
    refreshUI();
    if (room.status === 'finished') toast('本副牌已结束，请洗牌');
  });

  G.unwatchMe = watchHand(roomId, playerId, (data) => {
    applyPlayerData(data);
    refreshUI();
  });
}
